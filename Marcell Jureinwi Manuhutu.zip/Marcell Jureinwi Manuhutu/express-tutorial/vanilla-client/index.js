const dataBuku = document.getElementById("listBuku");
const buttonDetail = document.getElementById("detail");

const getBuku = async() =>{
    const response = await fetch("http://localhost:5000");
    const result = await response.json();
    return result.data;
};

const renderBuku = (dataBuku)=>{
    listBuku.map((buku)=>{

    })
}