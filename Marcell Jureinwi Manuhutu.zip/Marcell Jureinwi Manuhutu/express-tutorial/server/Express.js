const express = require("express");
const app = express();
const mysql = require("mysql");

const pool = mysql.createPool({
    connectionLimit : 10,
    host : "localhost",
    user : "root",
    password : "",
    database : "71220855"
});

const bodyParser = require("body-parser");
const jsonParser = bodyParser.json();




app.get("/buku", (req, res) => {
    pool.getConnection((err, connection) => {
    if (err) throw err;
    connection.query("SELECT * from buku", (err, rows) => {
    connection.release(); 
    if (!err) {
        res.status(200).json({ data: rows });
    } else {
        res.status(500).json({ error: err });
    };
});
});
});




app.get("/buku/:id", 
    (req, res)=> {
        pool.getConnection((err, connection) =>{
            if(err) throw err;
            connection.query(
                "SELECT * FROM buku WHERE id = ?", [req.params.id],
                (err, rows) =>{
                    connection.release();
                    if(!err){
                        res.status(200).json({data: rows});
                    }else{
                        res.status(500).json({errpr: err});
            }
        })
    })
});

app.post("/buku", jsonParser,
    (req, res)=>{
        pool.getConnection((err, connection) => {
            if (err) throw err;
            const params = req.body;
            connection.query("INSERT INTO buku SET ?", params, (err, rows) => {
                connection.release();
                if (!err){
                    res.status(200).json({data: rows});
                }else {
                    res.status(500).json({error: err});
                }
            });
        });
    });
    





const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
        console.log(`Server Berhasil di port ${PORT}`);
});